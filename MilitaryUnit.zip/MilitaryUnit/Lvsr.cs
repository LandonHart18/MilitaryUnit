﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryUnit
{
    class Lvsr : MilVehicle
    {
        public void towWeight()
        {
            Console.WriteLine("The max tow weight is 15000lbs");
        }

        public void StartSound()
        {
            Console.WriteLine("Brgrbrgrbrgr!");
        }
    }
}
