﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryUnit
{
    class SevenTon : MilVehicle
    {
        public void numOfPplCarry()
        {
            Console.WriteLine("Number of people it can carry is 16.");
        }

        public void StartSound()
        {
            Console.WriteLine("GRGRRGRRGGR!");
        }
    }
}
