﻿using System;

namespace MilitaryUnit
{
    class Program
    {
        static void Main(string[] args)
        {
            SevenTon sevenTon = new SevenTon();
            sevenTon.numOfPplCarry();
            sevenTon.typeOfEngine = "V8";
            sevenTon.numOfTires = 6;
            sevenTon.numOfMiles = 48000;
            sevenTon.PrintBase();
            sevenTon.StartSound();

            Lvsr lvsr = new Lvsr();
            lvsr.towWeight();
            lvsr.typeOfEngine = "V12";
            lvsr.numOfTires = 10;
            lvsr.numOfMiles = 53000;
            lvsr.PrintBase();
            lvsr.StartSound();
        }


    }
}
