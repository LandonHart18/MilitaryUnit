﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryUnit
{
    class MilVehicle
    {
        public string typeOfEngine;
        public int numOfTires;
        public int numOfMiles;

        public void PrintBase()
        {
            Console.WriteLine("Type of Engine: " + typeOfEngine);
            Console.WriteLine("Number of Tires: " + numOfTires);
            Console.WriteLine("Number of Miles Driven: " + numOfMiles);
        }
    }
}
